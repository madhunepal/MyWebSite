# Project Overview

This is a modern full-stack web application built with React frontend, Express.js backend, and PostgreSQL database using Drizzle ORM. The application appears to be a personal portfolio website for Madhu Nepal, featuring multiple sections including hero, about, skills, experience, projects, blog, and contact.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state
- **Build Tool**: Vite for development and production builds
- **UI Components**: Comprehensive component library using Radix UI primitives

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Module System**: ES Modules (type: "module")
- **Development**: tsx for TypeScript execution in development
- **Production Build**: esbuild for server bundling

### Database Architecture
- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with drizzle-kit for migrations
- **Schema Location**: Shared schema at `shared/schema.ts`
- **Connection**: Uses `@neondatabase/serverless` driver

## Key Components

### Database Schema
- **Users Table**: Basic user entity with id, username, and password fields
- **Schema Validation**: Zod integration for type-safe validation
- **Migrations**: Configured to output to `./migrations` directory

### Storage Layer
- **Interface**: `IStorage` interface defining CRUD operations
- **Implementation**: In-memory storage (`MemStorage`) for development
- **Methods**: User creation, retrieval by ID and username

### Frontend Structure
- **Components**: Organized into sections (hero, about, skills, etc.) and UI components
- **Hooks**: Custom hooks for intersection observer, scroll spy, mobile detection
- **Pages**: Home page and 404 not found page
- **Styling**: Dark theme with custom CSS variables and glass morphism effects

### Development Tools
- **Hot Reload**: Vite HMR with runtime error overlay
- **TypeScript**: Strict configuration with path mapping
- **Linting**: ESLint configuration implied by component structure
- **PostCSS**: Autoprefixer and Tailwind CSS processing

## Data Flow

### Client-Side Data Flow
1. React Query manages server state and caching
2. Custom hooks handle UI interactions (scroll spy, intersection observer)
3. Components use shadcn/ui for consistent styling
4. Wouter handles client-side routing

### Server-Side Data Flow
1. Express middleware handles JSON parsing and logging
2. Routes are registered through `registerRoutes` function
3. Storage interface abstracts data persistence
4. Error handling middleware provides consistent error responses

### Development vs Production
- **Development**: Vite middleware serves frontend with HMR
- **Production**: Static files served from `dist/public`
- **API Routes**: Prefixed with `/api` for clear separation

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React with extensive Radix UI component suite
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation
- **Carousel**: Embla Carousel for interactive elements

### Backend Dependencies
- **Database**: Neon PostgreSQL with Drizzle ORM
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution

### Development Dependencies
- **Build Tools**: Vite with React plugin and TypeScript support
- **Replit Integration**: Custom plugins for Replit environment
- **Error Handling**: Runtime error modal for development

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite compiles React application to `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations can be applied via `npm run db:push`

### Environment Configuration
- **Database URL**: Required environment variable for PostgreSQL connection
- **Node Environment**: Separate configurations for development and production
- **Static Assets**: Frontend assets served from build output directory

### Production Considerations
- **Database**: Configured for PostgreSQL with connection pooling
- **Error Handling**: Comprehensive error middleware for API routes
- **Logging**: Request logging for API endpoints with response capture
- **Security**: CORS and other security considerations handled by Express middleware

The application is designed as a portfolio website with a clean separation between frontend and backend, using modern web development practices and a scalable architecture that can easily extend to include user authentication, content management, and additional features.